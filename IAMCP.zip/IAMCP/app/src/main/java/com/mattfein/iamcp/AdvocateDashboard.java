package com.mattfein.iamcp;


import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.CardView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


/**
 * A simple {@link Fragment} subclass.
 */
public class AdvocateDashboard extends Fragment {

    CardView repCard, issueCard, advocateCard;


    public AdvocateDashboard() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_advocte_dashboard, container, false);
        repCard = v.findViewById(R.id.representativesCard);
        issueCard = v.findViewById(R.id.issueCard);
        advocateCard = v.findViewById(R.id.advocateCard);

        setUpClickListeners(repCard, issueCard, advocateCard);


        return v;
    }

    private void setUpClickListeners(CardView repCard, CardView issueCard, CardView advocateCard) {

        //RepCard Click Listener
        repCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent issueActivity = new Intent(getActivity(), repActivity.class);
                startActivity(issueActivity);
            }
        });

        //IssueCard Click Listener
        issueCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent issueActivity = new Intent(getActivity(), issueActivity.class);
                startActivity(issueActivity);
            }
        });

        //AdvocateCard Click Listener
        advocateCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent issueActivity = new Intent(getActivity(), advocateActivity.class);
                startActivity(issueActivity);

            }
        });

    }

}
