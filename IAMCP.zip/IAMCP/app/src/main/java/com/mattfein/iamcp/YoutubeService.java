package com.mattfein.iamcp;

public class YoutubeService {
    public YoutubeService(){

    }

    private String api = "AIzaSyAmmevt501yRRzhSDBk3m8PY1TuQkVLrNg";
    public String getApi(){
        return api;
    }

}
